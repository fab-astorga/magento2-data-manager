<?php

namespace Integration\Netsuite\Api;

interface DataAuthInterface 
{
    const CONSUMER_KEY = 'b2ca33442105f446981b035a481944564c323fd45facb32b5ad0bfc16a62bfb3';

    const CONSUMER_SECRET = 'acca0767967483db62c3cc54f95ef972e800f26f8aa26913ba1d9e93050ae1dd';

    const TOKEN_ID = 'd6d62062c988645c497e4ffcfbb0e03cb431d4b6ba872c5b71bedfee08c031cd';

    const TOKEN_SECRET = 'f347b1fbb729e7456a49113d7d86e2b4d551aca99aa30e8cd3a95e1b61334393';

    const RESTLET_URL = 'https://560765-sb1.restlets.api.netsuite.com/app/site/hosting/restlet.nl';
}