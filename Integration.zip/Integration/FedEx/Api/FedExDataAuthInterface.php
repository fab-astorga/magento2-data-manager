<?php

namespace Integration\FedEx\Api;

interface FedExDataAuthInterface 
{
    const KEY = 'sLY6uYKnTAq9b3Nv';

    const PASSWORD = '7QGkYdYX9nDLCSN9ZL7lUS992';

    const ACCOUNT_NUMBER = '510087720';

    const METER_NUMBER = '119022706';

    const URL = 'https://wsbeta.fedex.com:443/web-services/rate';
}